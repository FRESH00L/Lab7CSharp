﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Linq;
using System.Collections.Generic;
using System.Collections.Immutable;

namespace Lab6
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public static class LinqExtention
    {
        public static (T, T) MinMax<T, TKey>(this IEnumerable<T> source, Func<TKey> selector) where T : IComparable<T> where TKey : IEnumerable<TKey>
        {
            if (source == null) { throw new ArgumentNullException("invalid source"); }
            T min = source.First();
            T max = source.First();
            foreach (var item in source)
            {
                if (item.CompareTo(min) < 0)
                { min = item; }
                if (item.CompareTo(max) > 0)
                { max = item; }
            }
            return (min, max);
        }

    }
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        
        enum kategoria { Jedzenie, Picie, Slodycz };
        class Towar 
        {
            public string Nazwa { get; set; }
            public double Cena { get; set; }
            public int Ilosc { get; set; }
            public kategoria Kategoria { get; set; }
            public override string ToString()
            {
                return $"{Nazwa}: {Cena}zł, {Ilosc} sztuk, kat: {Kategoria}";
            }
        }
        List<Towar> listaTowarow = new List<Towar>
        {
            new Towar {Nazwa = "Sok", Ilosc = 10, Cena = 5.99, Kategoria = kategoria.Picie},
            new Towar {Nazwa = "Woda", Ilosc = 100, Cena = 1.99, Kategoria = kategoria.Picie},
            new Towar {Nazwa = "Energol", Ilosc = 40, Cena = 7.99, Kategoria = kategoria.Picie},
            new Towar {Nazwa = "Chleb", Ilosc = 7, Cena = 4.99, Kategoria = kategoria.Jedzenie},
            new Towar {Nazwa = "Bułka", Ilosc = 3, Cena = 1.59, Kategoria = kategoria.Jedzenie},
            new Towar {Nazwa = "Makaron", Ilosc = 15, Cena = 5.99, Kategoria = kategoria.Jedzenie},
            new Towar {Nazwa = "Cukierek", Ilosc = 2, Cena = 0.99, Kategoria = kategoria.Jedzenie},
            new Towar {Nazwa = "Batonik", Ilosc = 60, Cena = 3.99, Kategoria = kategoria.Slodycz},
            new Towar {Nazwa = "Chipsy", Ilosc = 10, Cena = 5.99, Kategoria = kategoria.Slodycz},
            new Towar {Nazwa = "Lizak", Ilosc = 9, Cena = 3.99, Kategoria = kategoria.Slodycz}
        };

        private void btn_1_Click(object sender, RoutedEventArgs e)
        {
            var towary = listaTowarow.Where(t => t.Ilosc > 5).Select(t => t);
            string dane = "";
            foreach(var t in towary) 
            {
                dane += $"\n{t.ToString()}";
            }
            lbl_wynik.Content = dane;
        }

        private void btn_2_Click(object sender, RoutedEventArgs e)
        {
            var wybrane = cbx_wybor.Text;
            var towary = listaTowarow.Where(t=> t.Kategoria.ToString()==wybrane).Select(t => t);
            string dane = "";
            foreach (var t in towary)
            {
                dane += $"\n{t.ToString()}";
            }
            lbl_wynik.Content = dane;
        }

        private void btn_3_Click(object sender, RoutedEventArgs e)
        {
            double srednia = listaTowarow.Average(t => t.Cena);
            var towary = listaTowarow.Where(t => t.Cena>srednia).Select(t => t);
            string dane = "";
            foreach (var t in towary)
            {
                dane += $"\n{t.Nazwa.ToString()}: {t.Cena}zł";
            }
            lbl_wynik.Content = dane;
        }

        private void btn_4_Click(object sender, RoutedEventArgs e)
        {
            
            string dane = "";
            for(int i = 0;i<= 2;i++)
            {
                var towary = listaTowarow.Where(t => (int)t.Kategoria == i).Select(t => t);
                double srednia = towary.Average(t => t.Cena);
                foreach(var t in towary)
                    dane += $"\n{t.Kategoria}: {t.Ilosc}, {t.Cena}zł";
            }
            lbl_wynik.Content = dane;
        }

        private void btn_5_Click(object sender, RoutedEventArgs e)
        {
            var towary = listaTowarow.OrderByDescending(t => t.Cena).FirstOrDefault();
            string dane = "";
            
            dane += $"{towary.Nazwa}, {towary.Cena}";
            
            lbl_wynik.Content = dane;   
        }
    }
}