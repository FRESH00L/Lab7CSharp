﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Linq;
using System.Xml.Serialization;
using Microsoft.Win32;
using System.Text.Json;
using System.Text.Json.Serialization;


namespace Lab7
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    
    public partial class MainWindow : Window
    {
        private Grupa grupa;
        public MainWindow()
        {
            InitializeComponent();
            List<Student> studenci = new List<Student>()
            {
                new Student() {Nazwisko = "Kowalski", Ocena = 4.5 },
                new Student() {Nazwisko = "Wiśniowski", Ocena = 5.0 },
                new Student() {Nazwisko = "Nowak", Ocena = 4.0 },
            };
            grupa = new Grupa() { Nazwa = "I16", Studenci = studenci };
            

        }

        private void btn_Melduj_Click(object sender, RoutedEventArgs e)
        {
            using (FileStream fs = new FileStream("rejestr.txt", FileMode.Append))
            {
                using (StreamWriter sw = new StreamWriter(fs))
                {
                    string dane = $"{DateTime.Now.ToString("yyyy-mm-dd")}";
                    sw.WriteLine(dane);
                }
            }
            
        }

        private void btn_Czytaj_Click(object sender, RoutedEventArgs e)
        {
            string filePath = "C:\\Users\\ASUS\\source\\repos\\Lab7\\dane.txt";
            using (FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read))
            {
                using (StreamReader sr = new StreamReader(fs))
                {
                    double srednia;
                    double min;
                    double max;
                    List<double> lista= new List<double> ();
                    while (!sr.EndOfStream)
                    {
                        double liczba = double.Parse(sr.ReadLine());
                        lista.Add(liczba);
                        
                        lbx_lista.Items.Add(liczba.ToString("F3"));
                    }
                    srednia = lista.Average();
                    min = lista.Min();
                    max = lista.Max();
                    lbl_wyniki.Content = $" Średnia: {srednia:F3}\n min:{min:F3},\n max:{max:F3}";
                }
            }
        }
        public class Student
        {
            public string Nazwisko { get; set; }
            public double Ocena { get; set; }

        }
        public class Grupa
        {
            public string Nazwa { get; set; }
            public List<Student> Studenci { get; set; }
            public int LiczbaStudentow { get => Studenci.Count; }
            public double? SredniaOcen => Studenci.Count > 0 ? Studenci.Average(s => s.Ocena) : null;
            
            public void Wyswietl(ListBox listBox)
            {
                listBox.Items.Clear();
                
                listBox.Items.Add(FormatujDane());    
            }
            private string FormatujDane()
            {
                string dane = "";
                dane += $"Grupa: {Nazwa}";
                foreach (var student in Studenci)
                {
                    dane += $"\n\t{student.Nazwisko}   {student.Ocena}";
                }
                dane += $"\nLiczba Studentów: {LiczbaStudentow}\nŚrednia Ocen: {SredniaOcen}";
                return dane;
            }

            public void ZapiszDoPliku(string nazwaPliku)
            {

                using (FileStream fileStream = new FileStream(nazwaPliku, FileMode.Create, FileAccess.Write))
                {
                    using (StreamWriter streamWriter = new StreamWriter(fileStream))
                    {
                        streamWriter.Write(FormatujDane());

                    }
                }
                   
            }
        }

        private void btn_ZapiszXML_Click(object sender, RoutedEventArgs e)
        {
            
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "XML file (*.xml)|*.xml"; 
                if (saveFileDialog.ShowDialog() == true)
                {
                using (FileStream fs = new FileStream("grupa.xml", FileMode.Create))
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(Grupa));
                    serializer.Serialize(fs, grupa);

                }
            }
        }

        private void btn_WczytajXML_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                using (FileStream fs = new FileStream(openFileDialog.SafeFileName, FileMode.Open))
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(Grupa));
                    Grupa g = (Grupa)serializer.Deserialize(fs);
                    g.Wyswietl(lbx_lista);
                }
            }
        }

        private void btn_WczytajJSON_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                
                        string json = File.ReadAllText(openFileDialog.FileName);
                        Grupa g = JsonSerializer.Deserialize<Grupa>(json);
                        g.Wyswietl(lbx_lista);
                  

            }
        }

        private void btn_ZapiszJSON_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "JSON file (*.json) | *.json";
            if (saveFileDialog.ShowDialog() == true)
            {      
                string json = JsonSerializer.Serialize<Grupa>(grupa);
                File.WriteAllText(saveFileDialog.FileName,json);         
                
                    
            }
        }
    }

}